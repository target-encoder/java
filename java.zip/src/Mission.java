
public interface Mission {
	public Object getAttr(String name);
	public void setAttr(String name, Object val);
}
