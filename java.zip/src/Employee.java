
public interface Employee {
	public String getId();

	public void setId(String id);

	public String getName();

	public void setName(String name);

	public String getSurname();

	public void setSurname(String surname);

	public Object getAttr(String name);

	public void setAttr(String name, Object val);

}
