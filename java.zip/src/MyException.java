
public class MyException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6881659454297603792L;

	public MyException(String message) {
		super(message);
	}

}
